<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>CRUD PHP+MYSQL</h2>
        <menu>
            <a href="registro.html">Create</a><br>
            <a href="consultar.php">Read</a><br>
            <a href="">Update</a><br>
            <a href="">Delete</a>
        </menu>
    </body>
</html>
